//
//  OfflineSDKCommand.h
//  SDKCommandLineExample
//
//  Created by John Wang on 2014-05-28.
//  Copyright (c) 2014 Entrust Inc. All rights reserved.
//

#import "BaseSDKCommand.h"

@interface OfflineSDKCommand : BaseSDKCommand

@end
