//
//  InfoSDKCommand.h
//  Entrust IdentityGuard Mobile SDK
//  Command Line Example
//
//  Copyright (c) 2013 Entrust, Inc. All rights reserved.
//  Use is subject to the terms of the accompanying license agreement. Entrust Confidential.
//

#import "BaseSDKCommand.h"

@interface InfoSDKCommand : BaseSDKCommand

@end
