/**********************************************************************
	
	commonUtils.js
	
	공통 유틸리티 함수 모음
	
	Author : 류경민
	
	Copyright (c) 2001-2011 Uracle Co., Ltd. 
	166 Samseong-dong, Gangnam-gu, Seoul, 135-090, Korea All Rights Reserved.
	
	웹 개발시 사용되는 공통 유틸리티 함수 모음 
	(* 내용은 오픈 되어도 상관없음) 

************************************************************************/

//////////////////////////////////////////////////////////////////////////////////////////////////
// Prototype 함수 정의 

/**
 * String Trim() 구현
 * 문자열의 공백을 제거한다.
 */
String.prototype.trim = function() {  
       return this.replace(/^\s+|\s+$/g,"");  
}  
    
String.prototype.ltrim = function() {  
       return this.replace(/^\s+/,"");     
}  
     
String.prototype.rtrim = function() {  
       return this.replace(/\s+$/,"");     
}

/**
 * StringBuffer 클래스 제공
 * 문자열 연결 연산
 */
function StringBuffer() { 
   this.buffer = []; 
 } 

 StringBuffer.prototype.append = function append(string) { 
   this.buffer.push(string); 
   return this; 
 }; 

 StringBuffer.prototype.toString = function toString() { 
   return this.buffer.join(""); 
 };


//////////////////////////////////////////////////////////////////////////////////////////////////
// 날짜 처리 관련 

/**
 * 현재 날짜를 얻어온다.
 */
function getNowDate() {
	var d = new Date();
	var month = d.getMonth() + 1;
	if (month < 10)
		month = "0" + month;
	return "" + d.getFullYear() + month + d.getDate() + d.getHours() + d.getMinutes() + d.getSeconds();
}


//////////////////////////////////////////////////////////////////////////////////////////////////
// 데이터 처리 관련 

/**
 *  금액 표시 함수 ( 데이터 중 금액 데이터를 ","를 붙여 금액 표시를 하기 위한 함수 )  
 *
 *  arranged by AhYeon .2011-08-16
 */
function sizeComma(bytes){ 
    var vbyte = new String(bytes);
    var len = vbyte.length; var one; var two; var three;
    if(len > 3) {
        one = vbyte.substring(len-3,len);
        if(len > 6) {
            two = vbyte.substring(len-6,len-3);
            if(len > 9) {
                three = vbyte.substring(len-9,len-6);
                vbyte = vbyte.substring(0,len-9);
                vbyte = vbyte + ',' + three + ',' + two +  ',' + one;
            } else {
            vbyte = vbyte.substring(0,len-6);
            vbyte = vbyte + ',' + two +  ',' + one;
            }
        } else {
            vbyte = vbyte.substring(0,len-3);
            vbyte = vbyte + ',' + one;
        }
    } 
    return vbyte;
};
 

/** 
 * 날짜 처리 함수 ( 달력 날짜 '/' 붙인 후 리턴하는 함수 : 20110816 -> 2011/08/16 형태로 변형 )  
 * 넘어오는 param값이 '20110816' 형태일때 사용. '2011816' 형태는 불가능.(한자리 숫자는 '0'이 붙은 값이 넘어와야한다.)  
 *
 * created by AhYeon .2011-08-16 
 */
function calendarDiv(param){
    var year = (param).substring(0,4);
    var month = (param).substring(4,6);  
    if( param.length == 8 ){   
        var date = (param).substring(6,8);
        var days = year + "/" + month + "/" + date; 
    }else{
        var days = year + "/" + month; 
    }
    return days;
}



//////////////////////////////////////////////////////////////////////////////////////////////////
// 기타 유틸리티 함수 

/**
* 자바스크립트 파일 import
* @param {Object} url
*/
function importJavascript(url) {
    var tag = document.createElement("script");
    tag.type="text/javascript";
    tag.src = url;

    document.body.appendChild(tag);
}

/**
* get window size
*/
// NHS 20011-06-29
// 04 Device Width & Height
function getWindowSize() {
    var myWidth = 0;
    var myHeight = 0;
    if( typeof( window.innerWidth ) == 'number' ) {
        //Non-IE
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
        //IE 6+ in 'standards compliant mode'
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
    } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
        //IE 4 compatible
        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    }
    //window.alert( 'Width = ' + myWidth + ', Height = ' + myHeight);
    return {"width":myWidth, "height":myHeight};
}

/**
* 브라우저 체크 
* @return 브라우저 구분 문자열 
*/
function checkBrowser () {
    var agent=navigator.userAgent.toLowerCase();
    if (agent.indexOf('iphone')!=-1) {
        return 'iphone';
    } else if (agent.indexOf('ipad')!=-1) {
        return 'ipad';
    } else if (agent.indexOf('ipod')!=-1) {
        return 'ipod';
    } else if (agent.indexOf('android')!=-1) {
        return 'android';
    }
    return 'pc';
}


/**
* String으로 넘어온 데이터를 Json타입으로 변환
* @return Json데이터
*/
function ConvertToJson(originStr){
	var convToStr = JSON.stringify(originStr); 

	//헤더String 삭제
	convToStr = convToStr.replace("{\"___jsonPCallbackData\":\"", "").replace("___End\"}", "");

	//자바스크립트 정규식 Replace
	convToStr = convToStr.replace(/\'/gi, "\"");

	var convToJson = JSON.parse(convToStr);		
	return convToJson;
}


/**
* 이전 버튼 
*/
function onHistoryBackPage() {
	history.back(-1);
}  

function getUrl(url){
	var agent = navigator.userAgent.toLowerCase();
	if (Number(agent.indexOf('iphone')) > -1) {
        this.browser = 'IOS';
    } else if (Number(agent.indexOf('ipad')) > -1) {
        this.browser = 'IOS';
    } else if (Number(agent.indexOf('ipod')) > -1) {
		this.browser = 'IOS';
    } else if (Number(agent.indexOf('android')) > -1) {
        this.browser = 'ANDROID';
    } else if (Number(agent.indexOf('windows phone')) > -1) {
        this.browser = 'WINDOWSPHONE';
	} else {
		this.browser = 'NOT SUPPORT';
	}

	if(this.browser == "WINDOWSPHONE"){
		return location.hash;
	}
	else{
		return location.search;
	}
}