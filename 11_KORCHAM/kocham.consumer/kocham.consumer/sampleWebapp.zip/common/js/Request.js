﻿
mfnpObj = function(){

	var agent = navigator.userAgent.toLowerCase();
    if (Number(agent.indexOf('iphone')) > -1) {
            this.browser = 'IOS';
        } else if (Number(agent.indexOf('ipad')) > -1) {
            this.browser = 'IOS';
        } else if (Number(agent.indexOf('ipod')) > -1) {
    		this.browser = 'IOS';
        } else if (Number(agent.indexOf('android')) > -1) {
            this.browser = 'ANDROID';
        } else if (Number(agent.indexOf('windows phone')) > -1) {
            this.browser = 'WINDOWSPHONE';
    	} else {
    		this.browser = 'NOT SUPPORT';
    	}
}

mfnpObj.prototype = {
    getImage: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getImage(returnFunc,userSpecific);
                break;
            case 'IOS':
            var prop = "callbackFunc=" + returnFunc + "&userSpecific=" + userSpecific + "";
    	        window.webkit.messageHandlers.getImage.postMessage(prop);
                //window.location.href = "mfinity://getImage?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },

    getAddress: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getAddress(returnFunc,userSpecific);
                break;
            case 'IOS':
	            var prop = "callbackFunc=" + returnFunc + "&userSpecific=" + userSpecific + "";
    	        window.webkit.messageHandlers.getAddress.postMessage(prop);
                //window.location.href = "mfinity://getAddress?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },

    startSosService: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.startSosService(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.startSosService.postMessage(prop);
                //window.location.href = "mfinity://startSosService?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },

    stopSosService: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.stopSosService(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.stopSosService.postMessage(prop);
                //window.location.href = "mfinity://stopSosService?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },

    startSos: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.startSos(returnFunc,userSpecific);
                break;
            case 'IOS':
	            var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.startSos.postMessage(prop);
                //window.location.href = "mfinity://startSos?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },

    stopSos: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.stopSos(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.stopSos.postMessage(prop);
                
                //window.location.href = "mfinity://stopSos?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    
    setPushCallback: function(returnFunc,functionName){
        returnFunc = encodeURIComponent(returnFunc);
        functionName = encodeURIComponent(functionName);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setPushCallback(returnFunc,functionName);
                break;
            case 'IOS':
            	var prop = "callbackFunc=" + returnFunc + "&functionName=" + functionName + "";
    	        window.webkit.messageHandlers.setPushCallback.postMessage(prop);
                //window.location.href = "mfinity://setPushCallback?callbackFunc="+returnFunc+"&functionName="+functionName;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    
    getPushCallback: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getPushCallback(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc=" + returnFunc + "&userSpecific=" + userSpecific + "";
    	        window.webkit.messageHandlers.getPushCallback.postMessage(prop);
                //window.location.href = "mfinity://getPushCallback?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
     setIconBadge: function(returnFunc,userSpecific,badgeCount){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        badgeCount = encodeURIComponent(badgeCount);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setIconBadge(returnFunc,userSpecific,badgeCount);
                break;
            case 'IOS':
            	var prop = "callbackFunc=" + returnFunc + "&userSpecific="+userSpecific+"&badgeCount="+badgeCount;
    	        window.webkit.messageHandlers.setIconBadge.postMessage(prop);
                //window.location.href = "mfinity://setIconBadge?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&badgeCount="+badgeCount;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getSosSetting: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getSosSetting(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.getSosSetting.postMessage(prop);
                //window.location.href = "mfinity://getSosSetting?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getUserId: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getUserId(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.getUserId.postMessage(prop);
                //window.location.href = "mfinity://getUserId?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getUserPwd: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getUserPwd(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.getUserPwd.postMessage(prop);
                //window.location.href = "mfinity://getUserPwd?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getPushID: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getPushID(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.getPushID.postMessage(prop);
                //window.location.href = "mfinity://getPushID?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getGpsLocation: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getGpsLocation(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.getGpsLocation.postMessage(prop);
                //window.location.href = "mfinity://getGpsLocation?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setShakeDegree: function(returnFunc,userSpecific,degree){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        degree = encodeURIComponent(degree);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setShakeDegree(returnFunc,userSpecific,degree);
                break;
            case 'IOS':
	            var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&degree="+degree;
    	        window.webkit.messageHandlers.setShakeDegree.postMessage(prop);
                //window.location.href = "mfinity://setShakeDegree?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&degree="+degree;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setNfcMode: function(returnFunc,userSpecific,isUsed){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        isUsed = encodeURIComponent(isUsed);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setNfcMode(returnFunc,userSpecific,isUsed);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&isUsed="+isUsed;
    	        window.webkit.messageHandlers.setNfcMode.postMessage(prop);
                //window.location.href = "mfinity://setNfcMode?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&isUsed="+isUsed;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setBeaconMode: function(returnFunc,userSpecific,isUsed){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        isUsed = encodeURIComponent(isUsed);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setBeaconMode(returnFunc,userSpecific,isUsed);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&isUsed="+isUsed;
    	        window.webkit.messageHandlers.setBeaconMode.postMessage(prop);
                //window.location.href = "mfinity://setBeaconMode?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&isUsed="+isUsed;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setPowerKeySosEvent: function(returnFunc,userSpecific,isUsed){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        isUsed = encodeURIComponent(isUsed);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setPowerKeySosEvent(returnFunc,userSpecific,isUsed);
                break;
            case 'IOS':
	            var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&isUsed="+isUsed;
    	        window.webkit.messageHandlers.setPowerKeySosEvent.postMessage(prop);
                //window.location.href = "mfinity://setPowerKeySosEvent?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&isUsed="+isUsed;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setTracePositionTimer: function(returnFunc,userSpecific,interval){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        interval = encodeURIComponent(interval);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setTracePositionTimer(returnFunc,userSpecific,interval);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&interval="+interval;
    	        window.webkit.messageHandlers.setTracePositionTimer.postMessage(prop);
                //window.location.href = "mfinity://setTracePositionTimer?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&interval="+interval;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setSosLocationInterval: function(returnFunc,userSpecific,interval){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        interval = encodeURIComponent(interval);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setSosLocationInterval(returnFunc,userSpecific,interval);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&interval="+interval;
    	        window.webkit.messageHandlers.setSosLocationInterval.postMessage(prop);
                //window.location.href = "mfinity://setSosLocationInterval?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&interval="+interval;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setLocationInterval: function(returnFunc,userSpecific,interval){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        interval = encodeURIComponent(interval);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setLocationInterval(returnFunc,userSpecific,interval);
                break;
            case 'IOS':
               	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&interval="+interval;
    	        window.webkit.messageHandlers.setLocationInterval.postMessage(prop);
                //window.location.href = "mfinity://setLocationInterval?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&interval="+interval;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setSosNotiMode: function(returnFunc,userSpecific,mode){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        mode = encodeURIComponent(mode);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setSosNotiMode(returnFunc,userSpecific,mode);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&mode="+mode;
    	        window.webkit.messageHandlers.setSosNotiMode.postMessage(prop);
                //window.location.href = "mfinity://setSosNotiMode?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&mode="+mode;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setCaptureMode: function(returnFunc,userSpecific,mode){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        mode = encodeURIComponent(mode);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setCaptureMode(returnFunc,userSpecific,mode);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&mode="+mode;
    	        window.webkit.messageHandlers.setCaptureMode.postMessage(prop);
                //window.location.href = "mfinity://setCaptureMode?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&mode="+mode;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setSosUserIdx: function(returnFunc,userSpecific,id){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        id = encodeURIComponent(id);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setSosUserIdx(returnFunc,userSpecific,id);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&id="+id;
    	        window.webkit.messageHandlers.setSosUserIdx.postMessage(prop);
                //window.location.href = "mfinity://setSosUserIdx?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&id="+id;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getSosUserIdx: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);

        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getSosUserIdx(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.getSosUserIdx.postMessage(prop);
                //window.location.href = "mfinity://setSosUserIdx?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&id="+id;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setSosIdx: function(returnFunc,userSpecific,id){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        id = encodeURIComponent(id);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setSosIdx(returnFunc,userSpecific,id);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&id="+id;
    	        window.webkit.messageHandlers.setSosIdx.postMessage(prop);
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getSosIdx: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);

        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getSosIdx(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.getSosIdx.postMessage(prop);
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setSosServiceIdx: function(returnFunc,userSpecific,id){
            returnFunc = encodeURIComponent(returnFunc);
            userSpecific = encodeURIComponent(userSpecific);
            id = encodeURIComponent(id);
            switch(this.browser.toString()){
                case 'ANDROID':
                    window.mfinity.setSosServiceIdx(returnFunc,userSpecific,id);
                    break;
                case 'IOS':
	                var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&id="+id;
    		        window.webkit.messageHandlers.setSosServiceIdx.postMessage(prop);
                    //window.location.href = "mfinity://setSosServiceIdx?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&id="+id;
                    break;
                case 'NOT SUPPORT':
                    alert('not support')
                    break;
            }
    },
    getSosServiceIdx: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);

        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getSosServiceIdx(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
    	        window.webkit.messageHandlers.getSosServiceIdx.postMessage(prop);
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    
    setUserId: function(returnFunc,userSpecific,id){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        id = encodeURIComponent(id);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setUserId(returnFunc,userSpecific,id);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&id="+id;
   		        window.webkit.messageHandlers.setUserId.postMessage(prop);
                //window.location.href = "mfinity://setUserId?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&id="+id;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setUserPwd: function(returnFunc,userSpecific,pwd){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        pwd = encodeURIComponent(pwd);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setUserPwd(returnFunc,userSpecific,pwd);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&pwd="+pwd;
   		        window.webkit.messageHandlers.setUserPwd.postMessage(prop);
                //window.location.href = "mfinity://setUserPwd?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&pwd="+pwd;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    startTracePosition: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.startTracePosition(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
   		        window.webkit.messageHandlers.startTracePosition.postMessage(prop);
                //window.location.href = "mfinity://startTracePosition?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    stopTracePosition: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.stopTracePosition(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
   		        window.webkit.messageHandlers.stopTracePosition.postMessage(prop);
                //window.location.href = "mfinity://stopTracePosition?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getPreferences: function(returnFunc,userSpecific,keyList){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        keyList = encodeURIComponent(keyList);

        switch(this.browser.toString()){
            case 'ANDROID':
                if(keyList == 'undefined'){
                    window.mfinity.getPreferences(returnFunc,userSpecific);
                 }
                 else{
                    window.mfinity.getPreferences(returnFunc,userSpecific,keyList);
                 }
                break;
            case 'IOS':
            	var prop;
                if(keyList == 'undefined'){
                	prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                   //window.location.href = "mfinity://getPreferences?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;                
                }
                else{
	                prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&keyList="+keyList;
                   //window.location.href = "mfinity://getPreferences?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&keyList="+keyList;
                }
	        	window.webkit.messageHandlers.getPreferences.postMessage(prop);
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    setPreferences: function(returnFunc,userSpecific,data){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        data = encodeURIComponent(data);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.setPreferences(returnFunc,userSpecific,data);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&data="+data;
   		        window.webkit.messageHandlers.setPreferences.postMessage(prop);
                //window.location.href = "mfinity://setPreferences?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&data="+data;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    getGpsLocation: function(returnFunc,userSpecific){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.getGpsLocation(returnFunc,userSpecific);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
   		        window.webkit.messageHandlers.getGpsLocation.postMessage(prop);
                //window.location.href = "mfinity://getGpsLocation?callbackFunc="+returnFunc+"&userSpecific="+userSpecific;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    executeSms: function(returnFunc,userSpecific,msg,userList){
        returnFunc = encodeURIComponent(returnFunc);
        userSpecific = encodeURIComponent(userSpecific);
        msg = encodeURIComponent(msg);
        userList = encodeURIComponent(userList);
        switch(this.browser.toString()){
            case 'ANDROID':
                window.mfinity.executeSms(returnFunc,userSpecific,msg,userList);
                break;
            case 'IOS':
            	var prop = "callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&msg="+msg+"&userList="+userList;
   		        window.webkit.messageHandlers.executeSms.postMessage(prop);
                //window.location.href = "mfinity://executeSms?callbackFunc="+returnFunc+"&userSpecific="+userSpecific+"&msg="+msg+"&userList="+userList;
                break;
            case 'NOT SUPPORT':
                alert('not support')
                break;
        }
    },
    executeFileUpload: function(callbackFunc, userSpecific, fileName, upLoadPath){
		callbackFunc = encodeURIComponent(callbackFunc);
		userSpecific = encodeURIComponent(userSpecific);
		fileName = encodeURIComponent(fileName);
		upLoadPath = encodeURIComponent(upLoadPath);

		switch(this.browser.toString()){
		case 'IOS':
			var prop = "callbackFunc=" + callbackFunc + "&userSpecific=" + userSpecific + "&fileName=" + fileName + "&upLoadPath=" + upLoadPath;
   		    window.webkit.messageHandlers.executeFileUpload.postMessage(prop);
			//location.href="mfinity://executeFileUpload?callbackFunc=" + callbackFunc + "&userSpecific=" + userSpecific + "&fileName=" + fileName + "&upLoadPath=" + upLoadPath + "";
			break;
		case 'ANDROID': 
			window.mfinity.executeFileUpload(callbackFunc, userSpecific, fileName, upLoadPath);
			break;
		default: 
			alert('mFinity does not support this OS (or Device)')
			break;
		}
	},
    executeImageCrop: function(callbackFunc, userSpecific, path){
		callbackFunc = encodeURIComponent(callbackFunc);
		userSpecific = encodeURIComponent(userSpecific);
		path = encodeURIComponent(path);
		

		switch(this.browser.toString()){
		case 'IOS':
			var prop = "callbackFunc=" + callbackFunc + "&userSpecific=" + userSpecific + "&path=" + path;
   		    window.webkit.messageHandlers.executeImageCrop.postMessage(prop);
			//location.href="mfinity://executeFileUpload?callbackFunc=" + callbackFunc + "&userSpecific=" + userSpecific + "&fileName=" + fileName + "&upLoadPath=" + upLoadPath + "";
			break;
		case 'ANDROID': 
			window.mfinity.executeImageCrop(callbackFunc, userSpecific, path);
			break;
		default: 
			alert('mFinity does not support this OS (or Device)')
			break;
		}
	}
};
