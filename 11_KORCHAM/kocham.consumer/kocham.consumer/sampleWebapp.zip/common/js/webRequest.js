﻿
JSONPObj = function(){
	this.service = "http://ezpro1.mfrontiers.com:1598/dataGateListener/DataGate2";
	this.dataType = "jsonp";
	this.compNo = "10";
}

JSONPObj.prototype = {
	dataType: "jsonp",
    service: null,
    
    call: function(config, spName, params, callback) {
        var service = this.service;
        var paramKeys = null;


        paramKeys = $.jtomcatajaxurl({
              params: params != null ? params : {}
              });
		//alert(service+"&dbConfigKey=" + config + "&sprocName=" + spName + "&args=" + paramKeys + "&jsonPCallback=?&compNo=" + this.compNo);
		//window.prompt('Dialog text', service+"&dbConfigKey=" + config + "&sprocName=" + spName + "&args=" + paramKeys + "&jsonPCallback=?&compNo=" + this.compNo);
        $.ajax({
          type: "GET",
          url: service, 
          data: "&dbConfigKey=" + config + "&sprocName=" + spName + "&args=" + paramKeys + "&jsonPCallback=?&compNo=" + this.compNo,
          dataType: "jsonp",
          jsonp : "jsonPCallback",
          cache: false,
          contentType: "application/json; charset=utf-8",
          success: function(response) {
              if (callback) callback(response);
          },
          error: function(response){
          }
        });
    }
};